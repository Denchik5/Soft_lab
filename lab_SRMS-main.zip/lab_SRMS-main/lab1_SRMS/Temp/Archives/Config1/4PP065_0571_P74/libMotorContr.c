void FB_motor(void) {};
void _FB_motor(void) {};
void FB_Integrator(void) {};
void _FB_Integrator(void) {};
void FB_regulator(void) {};
void _FB_regulator(void) {};
